package modelo;

public class TipoBanco {

	private int tipoBanco_id;
	private String tipoBanco_sigla;

	public int getTipoBanco_id() {
		return tipoBanco_id;
	}

	public void setTipoBanco_id(int tipoBanco_id) {
		this.tipoBanco_id = tipoBanco_id;
	}

	public String getTipoBanco_sigla() {
		return tipoBanco_sigla;
	}

	public void setTipoBanco_sigla(String tipoBanco_sigla) {
		this.tipoBanco_sigla = tipoBanco_sigla;
	}

}